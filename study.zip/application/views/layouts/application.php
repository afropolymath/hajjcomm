<!DOCTYPE html>
<!--[if IE 8]> 				 <html class="no-js lt-ie9" lang="en" > <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en" > <!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title><?= $title; ?></title>

  
    <link rel="stylesheet" href="<?= "$base/$foundation_css"; ?>">

    <link rel="stylesheet" href="<?= "$base/$app_css"; ?>">

    <script src="<?= "$base/$modernizr"; ?>"></script>

</head>
<body>
    <div class="wrapper">
        <div id="header">
            <div class="row">
                <div id="logo"></div>
            </div>
        </div>
        <div id="page">
        	<?= $yield; ?>
        </div>
        <div class="push"></div>
    </div>
    <div id="footer">
        <div class="row">
            <div id="carousel">
                <?= img("images/logo_arm.jpg"); ?>
                <?= img("images/logo_chevron.jpg"); ?>
                <?= img("images/logo_dangote.jpg"); ?>
                <?= img("images/logo_cbn.jpg"); ?>
                <?= img("images/logo_arm.jpg"); ?>
                <?= img("images/logo_chevron.jpg"); ?>
                <?= img("images/logo_dangote.jpg"); ?>
                <?= img("images/logo_cbn.jpg"); ?>
            </div>
        </div>
    </div>
    <script src="<?= "$base/$jquery"; ?>"></script>
  
    <script src="<?= "$base/$foundation_js"; ?>"></script>

    <script type="text/javascript" language="javascript" src="<?= "$base/$caroufredsel_js"; ?>"></script>
    <!-- optionally include helper plugins -->
    <!--
    <script type="text/javascript" language="javascript" src="helper-plugins/jquery.mousewheel.min.js"></script>
    <script type="text/javascript" language="javascript" src="helper-plugins/jquery.touchSwipe.min.js"></script>
    <script type="text/javascript" language="javascript" src="helper-plugins/jquery.transit.min.js"></script>
    <script type="text/javascript" language="javascript" src="helper-plugins/jquery.ba-throttle-debounce.min.js"></script>
    -->
    <script>
        $(document).foundation();
        $(function() {
            $('#carousel').carouFredSel({
                items : 4,
                auto : {
                    duration:0.02,                      
                    pauseOnHover: true,
                    timeoutDuration : 0,
                    easing:"linear"
                }                   
            });
        });
    </script>
</body>
</html>